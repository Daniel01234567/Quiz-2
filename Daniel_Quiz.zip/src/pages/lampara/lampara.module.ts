import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LamparaPage } from './lampara';

@NgModule({
  declarations: [
    LamparaPage,
  ],
  imports: [
    IonicPageModule.forChild(LamparaPage),
  ],
})
export class LamparaPageModule {}
